/* TikTok Repost Cleaner — bookmarklet code, local-only; no network requests. */
(() => {
  'use strict';
  if (!/(^|\.)tiktok\.com$/i.test(location.hostname)) {
    alert('Откройте свой профиль на tiktok.com, затем запустите закладку.');
    return;
  }
  if (document.getElementById('trc-local-panel')) return;

  const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const state = { running: false, stopped: false, attempted: 0, skipped: 0, failures: 0, seen: new Set() };
  const ACTION_RE = /(?:remove|undo|delete)\s+(?:(?:the|your)\s+)?repost|(?:удалить|убрать|отменить)\s+(?:свой\s+)?репост|(?:vidaliti|pribrati)\s+repost|(?:remover|desfazer)\b.{0,20}repost/i;
  const REPOST_TAB_RE = /^(?:reposts?|репосты|репости)$/i;
  const waitFor = async (fn, timeout = 4500) => {
    const start = Date.now();
    while (!state.stopped && Date.now() - start < timeout) {
      const hit = fn(); if (hit) return hit;
      await sleep(170);
    }
    return null;
  };
  const visible = el => {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    const style = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && style.visibility !== 'hidden' && style.display !== 'none';
  };
  const label = el => [(el?.getAttribute('aria-label')), el?.getAttribute('title'), el?.innerText].filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
  const candidates = (selector) => [...document.querySelectorAll(selector)].filter(visible);
  const click = el => { if (!el) return false; (el.closest('button,[role="button"],[role="tab"],[role="menuitem"],a') || el).click(); return true; };
  const getRemove = () => candidates('button,[role="button"],[role="menuitem"],div[data-e2e],span').find(el => ACTION_RE.test(label(el)) && label(el).length < 90);
  const getTab = () => candidates('[data-e2e="repost-tab"],[role="tab"],button,div').find(el => {
    return el.getAttribute('data-e2e') === 'repost-tab' || (REPOST_TAB_RE.test(label(el)) && label(el).length < 40);
  });

  const panel = document.createElement('div');
  panel.id = 'trc-local-panel';
  panel.style.cssText = 'position:fixed;right:12px;bottom:12px;z-index:2147483647;width:min(330px,calc(100vw - 24px));color:#fff;background:#14151b;border:1px solid #343541;border-radius:16px;padding:16px;font:14px/1.4 system-ui,sans-serif;box-shadow:0 14px 50px #0008;';
  panel.innerHTML = '<div style="display:flex;align-items:center;justify-content:space-between"><strong style="font-size:17px">Repost Cleaner</strong><button id="trc-x" style="background:none;color:#aaa;border:0;font-size:24px">×</button></div><p id="trc-status" style="color:#afb0bc;margin:12px 0">Откройте свой профиль → Репосты. Затем нажмите «Начать».</p><div id="trc-count" style="margin-bottom:12px">Попыток: 0 · Пропущено: 0</div><div style="display:flex;gap:8px"><button id="trc-start" style="flex:1;background:#fe2c55;color:#fff;border:0;border-radius:9px;padding:12px;font-weight:700">Начать</button><button id="trc-stop" style="background:#333;color:#fff;border:0;border-radius:9px;padding:12px">Стоп</button></div><small style="display:block;color:#989aa9;margin-top:12px">Удаление необратимо. Работает только на этой странице TikTok, без передачи данных на сервер.</small>';
  document.body.appendChild(panel);
  const q = s => panel.querySelector(s);
  const status = s => { q('#trc-status').textContent = s; q('#trc-count').textContent = `Попыток: ${state.attempted} · Пропущено: ${state.skipped}`; };
  q('#trc-stop').onclick = () => { state.stopped = true; state.running = false; status('Остановка...'); };
  q('#trc-x').onclick = () => { state.stopped = true; panel.remove(); };

  function items() {
    // Prefer TikTok's repost-specific container; never use the ordinary Videos tab.
    const direct = candidates('[data-e2e="user-repost-item"]');
    if (direct.length) return direct;
    const selected = getTab();
    if (!selected || selected.getAttribute('aria-selected') === 'false') return [];
    const region = document.querySelector('[data-e2e="user-repost-list"], [data-e2e="repost-list"], [data-e2e="repost-video-list"]');
    return region ? [...region.querySelectorAll('a[href*="/video/"],a[href*="/photo/"]')].filter(visible) : [];
  }
  function itemKey(el) {
    const a = el.matches('a[href]') ? el : el.querySelector('a[href]');
    return a?.href || el.getAttribute('data-e2e') + ':' + (el.textContent || '').slice(0,100);
  }
  async function closeVideo() {
    const btn = candidates('[data-e2e="browse-close"],button[aria-label*="Close" i],button[aria-label*="Закрыть" i]')[0];
    if (btn) { click(btn); await sleep(500); return; }
    document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true}));
    await sleep(500);
  }
  async function removeOnce(item) {
    click(item.querySelector?.('a[href*="/video/"],a[href*="/photo/"]') || item);
    await sleep(800);
    let remove = await waitFor(getRemove, 2000);
    if (!remove) {
      const share = candidates('[data-e2e="share-icon"],[data-e2e="browse-share-icon"],button[data-e2e="share-btn"],button[aria-label*="Share" i],button[aria-label*="Поделиться" i]')[0];
      if (share) { click(share); remove = await waitFor(getRemove, 2500); }
    }
    if (!remove) { await closeVideo(); return false; }
    click(remove);
    await sleep(850);
    await closeVideo();
    return true;
  }
  async function start() {
    if (state.running) return;
    if (!/^\/@[^/]+/.test(location.pathname)) { status('Сначала откройте свой профиль tiktok.com/@имя.'); return; }
    if (!getTab()) { status('Вкладка «Репосты» не найдена. Попробуйте включить «Версию для ПК».'); return; }
    if (!confirm('Начать удаление всех доступных репостов? Отменить снятые репосты автоматически нельзя.')) return;
    state.running = true; state.stopped = false;
    q('#trc-start').disabled = true;
    click(getTab());
    await sleep(1300);
    let empties = 0;
    while (!state.stopped && state.attempted < 10000) {
      const next = items().find(el => !state.seen.has(itemKey(el)));
      if (!next) {
        window.scrollTo(0, document.body.scrollHeight);
        await sleep(1600);
        if (++empties >= 3) { status('Больше репостов не найдено. Проверьте вкладку вручную.'); break; }
        continue;
      }
      empties = 0;
      state.seen.add(itemKey(next));
      status('Обрабатываю следующий репост...');
      const success = await removeOnce(next);
      state.attempted += Number(success);
      state.skipped += Number(!success);
      status(success ? 'Действие снятия репоста выполнено.' : 'Не увидел кнопку «Удалить репост» — пропускаю.');
      if (!success && ++state.failures >= 5) { status('5 ошибок подряд. Остановлено, чтобы не нажать лишнее.'); break; }
      if (success) state.failures = 0;
      await sleep(2000 + Math.random() * 1500);
    }
    state.running = false;
    if (panel.isConnected) q('#trc-start').disabled = false;
  }
  q('#trc-start').onclick = () => start().catch(err => { console.error(err); state.running = false; if (panel.isConnected) { q('#trc-start').disabled = false; status('Ошибка сценария — см. консоль.'); } });
})();
