"""One-user TikTok browser controller. No TikTok password, cookies or tokens are persisted."""
from __future__ import annotations
import asyncio
import logging
import re
from dataclasses import dataclass, field
from urllib.parse import urlsplit
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError

LOG = logging.getLogger('repostcleaner')
REMOVE_LABEL = re.compile(r'^(?:remove\s+repost|undo\s+repost|delete\s+repost|удалить\s+репост|убрать\s+репост|отменить\s+репост)$', re.I)
SHARE_LABEL = re.compile(r'^(?:share|share video|поделиться|поделиться видео)$', re.I)
PROFILE_RE = re.compile(r'^https://(?:www\.)?tiktok\.com/@[^/?#]+(?:/repost(?:s)?)?/?(?:[?#].*)?$', re.I)
VIDEO_RE = re.compile(r'^https://(?:www\.)?tiktok\.com/@[^/?#]+/video/\d+(?:[?#].*)?$', re.I)


def safe_video_url(url: str) -> str | None:
    """Only allow absolute TikTok video links; strip tracking parameters."""
    try:
        p = urlsplit(url)
        clean = f'{p.scheme}://{p.netloc}{p.path}'
        if p.scheme != 'https' or p.hostname not in ('www.tiktok.com', 'tiktok.com'):
            return None
        return clean if VIDEO_RE.fullmatch(clean) else None
    except Exception:
        return None


def valid_profile(url: str) -> bool:
    return bool(PROFILE_RE.fullmatch(url))


@dataclass
class ServiceState:
    phase: str = 'idle'
    found: int = 0
    processed: int = 0
    removed: int = 0
    skipped: int = 0
    errors: int = 0
    message: str = 'Включите браузер и войдите в TikTok'
    videos: list[str] = field(default_factory=list)
    logs: list[dict] = field(default_factory=list)


class TikTokWorker:
    def __init__(self):
        self.pw = None
        self.browser = None
        self.context = None
        self.page = None
        self.lock = asyncio.Lock()
        self.stop_event = asyncio.Event()
        self.job: asyncio.Task | None = None
        self.state = ServiceState()

    def _log(self, status: str, url: str, detail: str = ''):
        self.state.logs.insert(0, {'status': status, 'url': url, 'detail': detail})
        del self.state.logs[80:]

    async def ensure_browser(self):
        if self.page is not None:
            return
        try:
            self.pw = await async_playwright().start()
            self.browser = await self.pw.chromium.launch(headless=True, args=['--no-sandbox', '--disable-dev-shm-usage'])
            self.context = await self.browser.new_context(
                viewport={'width': 1120, 'height': 730},
                device_scale_factor=1,
                locale='ru-RU',
                timezone_id='Europe/Moscow',
                permissions=[],
                accept_downloads=False,
            )
            self.page = await self.context.new_page()
            await self.page.goto('https://www.tiktok.com/login', wait_until='domcontentloaded', timeout=45000)
            self.state.message = 'Войдите в TikTok в окне браузера ниже'
        except Exception:
            await self.close()
            raise

    async def close(self):
        self.stop_event.set()
        if self.job and not self.job.done():
            self.job.cancel()
            try:
                await self.job
            except (asyncio.CancelledError, Exception):
                pass
        if self.context:
            await self.context.close()
        if self.browser:
            await self.browser.close()
        if self.pw:
            await self.pw.stop()
        self.pw = self.browser = self.context = self.page = None
        self.job = None
        self.state = ServiceState()
        self.stop_event = asyncio.Event()

    def busy(self) -> bool:
        return bool(self.job and not self.job.done())

    def get_status(self):
        return {
            'browser': self.page is not None,
            'url': self.page.url if self.page else None,
            'busy': self.busy(),
            'phase': self.state.phase,
            'found': self.state.found,
            'processed': self.state.processed,
            'removed': self.state.removed,
            'skipped': self.state.skipped,
            'errors': self.state.errors,
            'message': self.state.message,
            'logs': self.state.logs[:25],
        }

    async def screenshot(self) -> bytes:
        if self.page is None:
            raise ValueError('Браузер ещё не запущен')
        async with self.lock:
            return await self.page.screenshot(type='jpeg', quality=62, animations='disabled', timeout=12000)

    async def click(self, x: float, y: float):
        if not 0 <= x <= 1120 or not 0 <= y <= 730:
            raise ValueError('Координаты вне окна')
        await self.page.mouse.click(x, y)

    async def scroll(self, dy: int):
        if abs(dy) > 1600:
            raise ValueError('Слишком большой шаг прокрутки')
        await self.page.mouse.wheel(0, dy)

    async def key(self, key: str):
        allowed = {'Enter', 'Tab', 'Escape', 'Backspace', 'ArrowDown', 'ArrowUp', 'ArrowLeft', 'ArrowRight', 'Space'}
        if key not in allowed:
            raise ValueError('Клавиша недоступна')
        await self.page.keyboard.press(key)

    async def type_text(self, value: str):
        if len(value) > 512:
            raise ValueError('Слишком длинный текст')
        # Never log `value`: may contain a TikTok password or one-time code.
        await self.page.keyboard.insert_text(value)

    async def scan(self):
        if self.busy():
            raise ValueError('Предыдущая операция ещё выполняется')
        if self.page is None or not valid_profile(self.page.url):
            raise ValueError('Откройте в браузере свой профиль TikTok и вкладку «Репосты»')
        self.stop_event.clear()
        self.state = ServiceState(phase='scanning', message='Собираю ссылки на видео из открытой вкладки «Репосты»')
        self.job = asyncio.create_task(self._scan_job())

    async def _scan_job(self):
        seen: set[str] = set()
        stale = 0
        try:
            for _ in range(220):
                if self.stop_event.is_set():
                    self.state.phase = 'stopped'
                    self.state.message = 'Сканирование остановлено'
                    return
                async with self.lock:
                    if not valid_profile(self.page.url):
                        raise ValueError('Открыта другая страница. Сканирование остановлено')
                    links = await self.page.evaluate('''() => {
                      const selectors = [
                        '[data-e2e="user-post-item-list"] a[href*="/video/"]',
                        '[data-e2e="user-post-item"] a[href*="/video/"]',
                        'main a[href*="/video/"]',
                      ];
                      for (const selector of selectors) {
                        const result = Array.from(document.querySelectorAll(selector), a => a.href);
                        if (result.length) return result;
                      }
                      return [];
                    }''')
                    old_len = len(seen)
                    for link in links:
                        clean = safe_video_url(link)
                        if clean:
                            seen.add(clean)
                    self.state.found = len(seen)
                    self.state.message = f'Найдено {len(seen)} видео. Прокручиваю список…'
                    await self.page.evaluate('window.scrollBy(0, Math.max(window.innerHeight * 1.6, 850))')
                stale = stale + 1 if len(seen) == old_len else 0
                if stale >= 6:
                    break
                if len(seen) > 4000:
                    raise ValueError('Достигнут лимит 4000 репостов за одно сканирование')
                await asyncio.sleep(1.0)
            self.state.videos = list(seen)
            self.state.phase = 'ready'
            self.state.message = f'Найдено {len(seen)} ссылок. Перед удалением подтвердите действие. Удаляться будут только подтверждённые TikTok репосты.'
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            LOG.warning('Scan failed: %s', type(exc).__name__)
            self.state.phase = 'error'
            self.state.message = f'Не удалось собрать репосты: {exc}'

    async def start_delete(self, expected_count: int):
        if self.busy():
            raise ValueError('Другая операция ещё выполняется')
        if self.state.phase != 'ready' or not self.state.videos:
            raise ValueError('Сначала выполните сканирование')
        if expected_count != len(self.state.videos):
            raise ValueError('Количество репостов изменилось, подтвердите заново')
        self.stop_event.clear()
        self.state.phase = 'deleting'
        self.state.removed = self.state.skipped = self.state.errors = self.state.processed = 0
        self.state.message = 'Удаляю только репосты с явно найденной кнопкой «Удалить репост»'
        self.job = asyncio.create_task(self._delete_job())

    async def _share_then_find_remove(self):
        """Conservative UI-only operation: never click a generic 'Repost' button."""
        possible_share = [
            '[data-e2e="browse-share-icon"]',
            '[data-e2e="share-icon"]',
            '[data-e2e="video-share"]',
            'button[aria-label="Share"]',
            'button[aria-label="Поделиться"]',
        ]
        for selector in possible_share:
            node = self.page.locator(selector).first
            try:
                if await node.count() and await node.is_visible(timeout=500):
                    await node.click(timeout=2500)
                    await asyncio.sleep(0.65)
                    break
            except Exception:
                continue
        else:
            button = self.page.get_by_role('button', name=SHARE_LABEL).first
            if not await button.count():
                return False
            await button.click(timeout=2500)
            await asyncio.sleep(0.65)
        target = self.page.get_by_text(REMOVE_LABEL).first
        if not await target.count():
            return False
        if not await target.is_visible(timeout=1500):
            return False
        await target.click(timeout=3000)
        await asyncio.sleep(0.75)
        return True

    async def _has_challenge(self) -> bool:
        try:
            return bool(await self.page.locator('iframe[src*="captcha"], [id*="captcha"], [class*="captcha"]').count())
        except Exception:
            return False

    async def _delete_job(self):
        try:
            for url in self.state.videos:
                if self.stop_event.is_set():
                    self.state.phase = 'stopped'
                    self.state.message = 'Остановлено. Новые видео больше не обрабатываются.'
                    return
                async with self.lock:
                    try:
                        await self.page.goto(url, wait_until='domcontentloaded', timeout=35000)
                        await asyncio.sleep(1.1)
                        if await self._has_challenge():
                            self.state.phase = 'blocked'
                            self.state.message = 'TikTok запросил проверку. Автоматизация остановлена.'
                            return
                        result = await self._share_then_find_remove()
                        if result:
                            self.state.removed += 1
                            self._log('removed', url)
                        else:
                            self.state.skipped += 1
                            self._log('skipped', url, 'Кнопка удаления репоста не найдена — ничего не нажато')
                    except PlaywrightTimeoutError:
                        self.state.errors += 1
                        self._log('error', url, 'Таймаут')
                    except Exception:
                        self.state.errors += 1
                        self._log('error', url, 'Интерфейс TikTok недоступен')
                    self.state.processed += 1
                    self.state.message = f'Обработано {self.state.processed} из {len(self.state.videos)}. Нажата кнопка удаления для {self.state.removed}.'
                await asyncio.sleep(2.7)
            self.state.phase = 'done'
            self.state.message = f'Готово. Нажата кнопка удаления для {self.state.removed} видео, пропущено {self.state.skipped}. Проверьте результат в TikTok.'
        except asyncio.CancelledError:
            raise
        except Exception:
            self.state.phase = 'error'
            self.state.message = 'Процесс остановился из-за непредвиденной ошибки'

    def stop(self):
        self.stop_event.set()
        self.state.message = 'Останавливаю после текущего действия…'
