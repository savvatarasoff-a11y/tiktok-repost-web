"""Self-hosted web dashboard for TikTok repost cleanup.

A genuine TikTok OAuth token cannot delete reposts. This site operates a
short-lived interactive remote Chromium browser after the user logs into
TikTok themselves. No TikTok session is saved to files or database.
"""
import asyncio
import hmac
import os
import secrets
import time
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI, HTTPException, Request, Response, Depends
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from .worker import TikTokWorker

ROOT = Path(__file__).parent
ACCESS_LINK_TOKEN = os.environ.get('ACCESS_LINK_TOKEN', '')
if not ACCESS_LINK_TOKEN or len(ACCESS_LINK_TOKEN) < 32:
    raise RuntimeError('ACCESS_LINK_TOKEN must have at least 32 characters')

worker = TikTokWorker()
tokens: dict[str, float] = {}
SESSION_SECONDS = 12 * 3600


@asynccontextmanager
async def lifespan(app: FastAPI):
    yield
    await worker.close()


app = FastAPI(title='Repost Cleaner Web', lifespan=lifespan, docs_url=None, redoc_url=None)


class LinkBody(BaseModel):
    key: str = Field(min_length=1, max_length=200)


class Coordinates(BaseModel):
    x: float
    y: float


class ScrollBody(BaseModel):
    dy: int


class KeyBody(BaseModel):
    key: str = Field(max_length=25)


class TypeBody(BaseModel):
    text: str = Field(max_length=512)


class DeleteBody(BaseModel):
    count: int = Field(ge=0, le=4000)
    confirmed: bool


def authorized(request: Request):
    token = request.cookies.get('repost_session', '')
    expiry = tokens.get(token, 0)
    if not token or expiry < time.time():
        if token:
            tokens.pop(token, None)
        raise HTTPException(status_code=401, detail='Требуется вход в панель')
    return True


def csrf(request: Request):
    # Cookie-authenticated POST endpoints reject cross-site requests.
    origin = request.headers.get('origin')
    if origin:
        from urllib.parse import urlparse
        parsed = urlparse(origin)
        host = request.headers.get('host', '')
        if parsed.netloc != host or parsed.scheme not in ('http', 'https'):
            raise HTTPException(403, detail='Недопустимый источник запроса')


@app.get('/')
async def index():
    return FileResponse(ROOT / 'static' / 'index.html', headers={'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer'})


@app.get('/static/{file_name}')
async def asset(file_name: str):
    if file_name not in ('app.js', 'style.css'):
        raise HTTPException(404)
    return FileResponse(ROOT / 'static' / file_name)


@app.post('/api/link-login')
async def link_login(body: LinkBody, request: Request, response: Response):
    # The personal link uses an URL fragment (#key=...), never sent in
    # HTTP requests or web server access logs. JS exchanges it for a cookie.
    csrf(request)
    if not hmac.compare_digest(body.key, ACCESS_LINK_TOKEN):
        raise HTTPException(401, detail='Недействительная личная ссылка')
    token = secrets.token_urlsafe(36)
    tokens[token] = time.time() + SESSION_SECONDS
    response.set_cookie('repost_session', token, httponly=True, secure=True,
                        samesite='strict', max_age=SESSION_SECONDS, path='/')
    response.headers['Cache-Control'] = 'no-store'
    return {'ok': True}


@app.post('/api/logout')
async def logout(request: Request, response: Response, _=Depends(authorized)):
    csrf(request)
    tokens.pop(request.cookies.get('repost_session', ''), None)
    response.delete_cookie('repost_session', path='/')
    return {'ok': True}


@app.get('/api/status')
async def status(_=Depends(authorized)):
    return worker.get_status()


@app.post('/api/browser/start')
async def start_browser(request: Request, _=Depends(authorized)):
    csrf(request)
    if worker.busy():
        raise HTTPException(409, detail='Сначала остановите текущую задачу')
    try:
        async with worker.lock:
            await worker.ensure_browser()
        return worker.get_status()
    except Exception:
        raise HTTPException(503, detail='Не удалось запустить Chromium. Проверьте сервер.')


@app.post('/api/browser/close')
async def close_browser(request: Request, _=Depends(authorized)):
    csrf(request)
    await worker.close()
    return {'ok': True}


@app.get('/api/browser/screen.jpg')
async def screen(_=Depends(authorized)):
    try:
        img = await worker.screenshot()
        return Response(img, media_type='image/jpeg', headers={'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer'})
    except Exception:
        raise HTTPException(503, detail='Снимок браузера временно недоступен')


async def browser_action(request: Request, operation):
    csrf(request)
    if worker.page is None:
        raise HTTPException(409, detail='Браузер не запущен')
    if worker.busy():
        raise HTTPException(409, detail='Подождите окончания операции')
    try:
        async with worker.lock:
            await operation()
        return {'ok': True}
    except ValueError as exc:
        raise HTTPException(400, detail=str(exc))
    except Exception:
        raise HTTPException(503, detail='Не удалось управлять браузером')


@app.post('/api/browser/click')
async def click(body: Coordinates, request: Request, _=Depends(authorized)):
    return await browser_action(request, lambda: worker.click(body.x, body.y))


@app.post('/api/browser/scroll')
async def scroll(body: ScrollBody, request: Request, _=Depends(authorized)):
    return await browser_action(request, lambda: worker.scroll(body.dy))


@app.post('/api/browser/key')
async def key(body: KeyBody, request: Request, _=Depends(authorized)):
    return await browser_action(request, lambda: worker.key(body.key))


@app.post('/api/browser/type')
async def type_text(body: TypeBody, request: Request, _=Depends(authorized)):
    return await browser_action(request, lambda: worker.type_text(body.text))


@app.post('/api/scan')
async def scan(request: Request, _=Depends(authorized)):
    csrf(request)
    try:
        await worker.scan()
    except ValueError as exc:
        raise HTTPException(400, detail=str(exc))
    return worker.get_status()


@app.post('/api/delete')
async def delete(body: DeleteBody, request: Request, _=Depends(authorized)):
    csrf(request)
    if not body.confirmed:
        raise HTTPException(400, detail='Подтвердите действие')
    try:
        await worker.start_delete(body.count)
    except ValueError as exc:
        raise HTTPException(400, detail=str(exc))
    return worker.get_status()


@app.post('/api/stop')
async def stop(request: Request, _=Depends(authorized)):
    csrf(request)
    worker.stop()
    return worker.get_status()


@app.get('/healthz')
async def healthz():
    return {'ok': True}
