import importlib
import os
os.environ['APP_PASSWORD'] = 'test_only_password_12345'
from fastapi.testclient import TestClient
from repost_web.worker import safe_video_url, valid_profile


def test_safe_urls():
    assert safe_video_url('https://www.tiktok.com/@alice/video/123?abc=1') == 'https://www.tiktok.com/@alice/video/123'
    assert safe_video_url('http://www.tiktok.com/@alice/video/123') is None
    assert safe_video_url('https://not-tiktok.com/@alice/video/123') is None
    assert safe_video_url('https://www.tiktok.com.evil.com/@alice/video/123') is None
    assert safe_video_url('https://www.tiktok.com/@alice/post/123') is None
    assert valid_profile('https://www.tiktok.com/@alice')
    assert valid_profile('https://www.tiktok.com/@alice/reposts')
    assert not valid_profile('https://www.tiktok.com/@alice/video/123')


def test_login_and_routes():
    app = importlib.import_module('repost_web.app').app
    with TestClient(app, base_url='https://testserver') as client:
        assert client.get('/').status_code == 200
        assert client.get('/api/status').status_code == 401
        assert client.post('/api/login', json={'password':'bad'}).status_code == 401
        login = client.post('/api/login', json={'password':'test_only_password_12345'})
        assert login.status_code == 200
        assert 'Secure' in login.headers.get('set-cookie', '')
        assert client.get('/api/status').json()['browser'] is False
        assert client.post('/api/delete', json={'count':0,'confirmed':True}).status_code == 400
        assert client.post('/api/scan').status_code == 400
        assert client.post('/api/browser/click',json={'x':5,'y':5}).status_code == 409
        assert client.post('/api/logout').status_code == 200
        assert client.get('/api/status').status_code == 401
