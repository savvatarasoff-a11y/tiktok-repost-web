#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v docker >/dev/null || ! docker compose version >/dev/null 2>&1; then
  echo 'Нужны Docker и Docker Compose. Установите их на VPS (https://docs.docker.com/engine/install/ubuntu/).'
  exit 1
fi
if [ ! -f .env ]; then
  PASSWORD="$(python3 -c 'import secrets;print(secrets.token_urlsafe(20))' 2>/dev/null || tr -dc A-Za-z0-9 </dev/urandom | head -c 30)"
  umask 077
  printf 'APP_PASSWORD=%s\n' "$PASSWORD" > .env
  echo ''
  echo '===== ПАРОЛЬ ПАНЕЛИ (запиши и сохрани) ====='
  echo "$PASSWORD"
  echo '=========================================='
else
  echo 'Используется пароль из существующего .env'
fi
docker compose up -d --build
echo ''
echo 'Контейнеры запущены. Найди строку https://...trycloudflare.com в выводе:'
docker compose logs tunnel --tail=40
echo ''
echo 'Если ссылки пока нет, выполни: docker compose logs -f tunnel'
