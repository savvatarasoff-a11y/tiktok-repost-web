'use strict';
const $ = id => document.getElementById(id);
let status = null;
let haveAuth = false;
let refreshBusy = false;
let pollBusy = false;
let lastScreen = 0;
let toastTimer;

function toast(message) {
  const el = $('toast');
  el.textContent = message;
  el.classList.remove('hide');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add('hide'), 5500);
}
async function api(url, method = 'GET', data) {
  const options = {method, credentials:'same-origin', headers:{}};
  if (data !== undefined) { options.headers['Content-Type'] = 'application/json'; options.body = JSON.stringify(data); }
  const response = await fetch(url, options);
  let body;
  try { body = await response.json(); } catch { body = {}; }
  if (!response.ok) {
    if (response.status === 401 && url !== '/api/login') setAuth(false);
    throw Error(typeof body.detail === 'string' ? body.detail : `Ошибка сервера: ${response.status}`);
  }
  return body;
}
function setAuth(value){
  haveAuth = value;
  $('authView').classList.toggle('hide', value);
  $('dashboard').classList.toggle('hide', !value);
  $('logoutBtn').classList.toggle('hide', !value);
  $('connectionLabel').textContent = value ? 'Панель защищена' : 'Не подключено';
  $('healthDot').classList.toggle('connected', value);
}
function updateStatus(s){
  if (!s) return;
  status = s;
  $('statFound').textContent = s.found.toLocaleString('ru-RU');
  $('statProcessed').textContent = s.processed.toLocaleString('ru-RU');
  $('statRemoved').textContent = s.removed.toLocaleString('ru-RU');
  $('statSkipped').textContent = (s.skipped+s.errors).toLocaleString('ru-RU');
  $('startBrowserBtn').disabled = s.browser || s.busy;
  $('startBrowserBtn').textContent = s.browser ? '✓ Браузер запущен' : '◉ Открыть браузер TikTok';
  $('scanBtn').disabled = !s.browser || s.busy;
  $('deleteBtn').disabled = s.busy || s.phase !== 'ready' || s.found===0;
  $('stopBtn').disabled = !s.busy;
  $('closeBrowserBtn').disabled = !s.browser;
  $('phaseLabel').textContent = ({idle:'Готов к работе',scanning:'Сканирование',ready:'Готово к удалению',deleting:'Удаление репостов',stopped:'Остановлено',done:'Завершено',blocked:'Проверка TikTok',error:'Ошибка'})[s.phase] || 'Обработка';
  const progress = s.phase === 'done' ? 100 : s.phase === 'deleting' ? Math.round(s.processed / Math.max(s.found,1) * 100) : s.phase === 'scanning' ? 0 : 0;
  $('progressLabel').textContent = progress+'%';
  $('progressBar').style.width = progress+'%';
  $('statusMessage').textContent = s.message;
  $('browserTag').textContent = s.browser ? 'LIVE' : 'OFFLINE';
  $('browserTag').classList.toggle('on',s.browser);
  $('browserUrl').textContent = s.url || 'https://www.tiktok.com';
  $('screenPlaceholder').classList.toggle('hide',s.browser);
  if (!s.browser) $('screenImage').classList.add('hide');
  const list = $('logList');
  list.replaceChildren();
  if (!s.logs.length) {
    const empty = document.createElement('div'); empty.className='empty';
    empty.textContent='После запуска здесь появятся результаты обработки видео.';
    list.appendChild(empty);
  } else {
    for(const item of s.logs) {
      const row=document.createElement('div'); row.className='log';
      const tag=document.createElement('em'); tag.className=item.status;
      tag.textContent=({removed:'Нажато',skipped:'Пропуск',error:'Ошибка'})[item.status]||item.status;
      const anchor=document.createElement('a'); anchor.href=item.url; anchor.target='_blank';anchor.rel='noopener noreferrer';anchor.textContent=item.url.split('/').pop();
      row.append(tag,anchor);list.append(row);
    }
  }
}
async function poll(){
  if(!haveAuth || pollBusy) return;
  pollBusy=true;
  try { updateStatus(await api('/api/status')); } catch(e) { if(haveAuth) console.warn('Status unavailable',e.message); }
  finally { pollBusy=false; }
}
async function refreshScreen(force = false){
  if (!haveAuth || !status?.browser || refreshBusy) return;
  if(!force && Date.now()-lastScreen < 1300) return;
  refreshBusy=true;
  try {
    const res=await fetch('/api/browser/screen.jpg?ts='+Date.now(),{cache:'no-store'});
    if(!res.ok) throw Error('Screenshot error');
    const blob=await res.blob();
    const url=URL.createObjectURL(blob);
    const img=$('screenImage');
    const prev=img.dataset.blob;
    await new Promise((resolve,reject)=>{ const loader=new Image(); loader.onload=resolve;loader.onerror=reject;loader.src=url; });
    img.src=url; img.dataset.blob=url; img.classList.remove('hide');
    if(prev) URL.revokeObjectURL(prev);
    lastScreen=Date.now();
  } catch(e) { /* temporary navigation overlap */ }
  finally {refreshBusy=false;}
}
async function doAction(path,data){
  try{const s=await api(path,'POST',data);if(s && s.phase) updateStatus(s);else await poll();return true;}catch(e){toast(e.message);return false;}
}
$('authForm').addEventListener('submit',async e=>{
  e.preventDefault();$('authError').textContent='';
  const pass=$('adminPassword').value;
  try {await api('/api/login','POST',{password:pass});$('adminPassword').value='';setAuth(true);await poll();}
  catch(err){$('authError').textContent=err.message;}
});
$('logoutBtn').addEventListener('click', async ()=>{await doAction('/api/logout');setAuth(false);});
$('startBrowserBtn').addEventListener('click',()=>doAction('/api/browser/start'));
$('scanBtn').addEventListener('click', async ()=>{
  if(!confirm('Убедись, что в браузере открыт ТВОЙ профиль TikTok и вкладка «Репосты» (↻). Начать сканирование?'))return;
  await doAction('/api/scan');
});
$('deleteBtn').addEventListener('click',async ()=>{
  const n=status?.found||0;
  if(!n || !confirm(`Начать удаление ${n} найденных репостов? Действие нельзя отменить. Если TikTok не показывает кнопку удаления, видео будет пропущено.`)) return;
  await doAction('/api/delete',{count:n,confirmed:true});
});
$('stopBtn').addEventListener('click',()=>doAction('/api/stop'));
$('closeBrowserBtn').addEventListener('click',async()=>{if(!confirm('Завершить сеанс? Все временные данные браузера TikTok будут удалены.'))return;await doAction('/api/browser/close');});
$('refreshBtn').addEventListener('click',()=>refreshScreen(true));
const direct = (path,payload)=>async()=>{if(status?.busy) return;const ok=await doAction(path,payload);if(ok) setTimeout(()=>refreshScreen(true),450);};
$('scrollUpBtn').addEventListener('click',direct('/api/browser/scroll',{dy:-580}));
$('scrollDownBtn').addEventListener('click',direct('/api/browser/scroll',{dy:580}));
$('tabBtn').addEventListener('click',direct('/api/browser/key',{key:'Tab'}));
$('enterBtn').addEventListener('click',direct('/api/browser/key',{key:'Enter'}));
$('backBtn').addEventListener('click',direct('/api/browser/key',{key:'Backspace'}));
$('zoomBtn').addEventListener('click',()=>{$('screenHolder').classList.toggle('zoomed');$('zoomBtn').textContent=$('screenHolder').classList.contains('zoomed')?'⛶ Вписать по ширине':'⛶ Масштаб 1:1';});
$('showInputBtn').addEventListener('click',()=>{$('typeInput').type=$('typeInput').type==='password'?'text':'password';});
$('typeForm').addEventListener('submit',async e=>{
 e.preventDefault();if(status?.busy)return;
 const input=$('typeInput');const value=input.value;
 if(!value)return;
 if(await doAction('/api/browser/type',{text:value})){input.value='';setTimeout(()=>refreshScreen(true),500);}
});
$('screenImage').addEventListener('click',async e=>{
  if(status?.busy) return;
  const img=e.currentTarget, r=img.getBoundingClientRect();
  const x=(e.clientX-r.left)/r.width*img.naturalWidth;
  const y=(e.clientY-r.top)/r.height*img.naturalHeight;
  if(await doAction('/api/browser/click',{x,y}))setTimeout(()=>refreshScreen(true),450);
});
$('screenImage').addEventListener('dblclick',e=>{e.preventDefault();$('screenHolder').classList.toggle('zoomed');});
// Check existing panel cookie without persisting auth or TikTok data in localStorage.
(async()=>{try {const s=await api('/api/status');setAuth(true);updateStatus(s);}catch{setAuth(false);}})();
setInterval(()=>{void poll();void refreshScreen();},1600);
